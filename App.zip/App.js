
import { createContext } from 'react'
import React from 'react';

import ClarigoTask from './ClarigoTask';
import Login1 from './Login1';
import Calculator1  from './Calculator1'
import RegistrationForm from './RegistrationForm'
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
   
  return(
    
    <ClarigoTask/>
   
  );
}


export default App;